
// Calculator


// let x = prompt(" Please enter the first number ");

// let y = prompt(" Please enter the second number ");

// let oper = prompt(" Enter an operator ");

// let result;


// if (oper == '+')
// {
//     result = Number(x) + Number(y);

// }

// else if (oper == '-')
// {
//     result = Number(x) - Number(y);
// }

// else if (oper == '*')
// {
//     result = Number(x) * Number(y);
// }

// else if (oper == '/')
// {
//     result = Number(x) / Number(y);
// }

// document.getElementById("demo").innerHTML = result;

//console.log(result);

//-------------------------------------------------------


// let red = prompt("Enter number 0 ");

// let result;


// if (red == 0)
// {
//     document.write("Its red, stay");
// }

// else if (red == 2)
// {
//     document.write("Its green, go");
// }

// else if (result != red)
// {
//     document.write("Wrong");
// }


//let a = prompt("Enter the number ");

let a = 7; //prompt("Enter the first number");
let b = 10; //prompt("Enter the second number");

if ( a > 2 && a < 11 || b >= 6 && b < 14)

{
    
    document.write("Right")
}
else
{
    
    document.write("Wrong");
}
