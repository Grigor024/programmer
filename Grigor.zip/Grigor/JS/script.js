
// Calculator


// let x = prompt(" Please enter the first number ");

// let y = prompt(" Please enter the second number ");

// let oper = prompt(" Enter an operator ");

// let result;


// if (oper == '+')
// {
//     result = Number(x) + Number(y);

// }

// else if (oper == '-')
// {
//     result = Number(x) - Number(y);
// }

// else if (oper == '*')
// {
//     result = Number(x) * Number(y);
// }

// else if (oper == '/')
// {
//     result = Number(x) / Number(y);
// }

// document.getElementById("demo").innerHTML = result;

// console.log(result);

//-------------------------------------------------------


// let red = prompt("Enter number 0 ");

// let result;


// if (red == 0)
// {
//     document.write("Its red, stay");
// }

// else if (red == 2)
// {
//     document.write("Its green, go");
// }

// else if (result != red)
// {
//     document.write("Wrong");
// }


//let a = prompt("Enter the number ");

// let a = 7; //prompt("Enter the first number");
// let b = 10; //prompt("Enter the second number");

// if ( a > 2 && a < 11 || b >= 6 && b < 14)

// {
    
//     document.write("Right")
// }
// else
// {
    
//     document.write("Wrong");
// }


// let day = Math.floor(Math.random() *31);

// let day1 = day;

// document.write( day, ' <br>  ');


// if ( day > 0 && day < 11 )
// {
//     document.write('It`s first decade')
// }
// else if ( day > 11 && day < 21 )
// {
//     document.write('It`s second decade')
// }
// else if ( day <= 31)
// {
//     document.write('It`s third decade')
// }


//MONTH


//let month = Math.floor(Math.random() *12); random

//let month_sezon = month;

//let month = prompt('enter');

//document.write( month_sezon, ' <br>  ');


// document.write( month, ' <br>  ');

// if ( month > 0 && month <= 2 )
// {
//     document.write('It`s winter')
// }
// else if ( month >= 3 && month <=5 )
// {
//     document.write('It`s spring')
// }
// else if ( month >=6 && month <= 8)
// {
//     document.write('It`s summer')
// }
// else if ( month >= 9 && month <= 10 )
// {
//     document.write('It`s autumn')
// }

// else
// {
//     document.write('It`s winter')
// }


// FOR

let i = 60;

for( i = 0; i <= 60; i = i + 2)
{
    document.write(' ', i);
}


