
let x = prompt(" Please enter the number ");

let y = prompt(" Please enter the number ");

let oper = prompt(" Enter an operator ");

let z = Number(x) + Number(y);





console.log(z);

// if (oper == "+")
// {
//     z = Number(x) + Number(y);
// }

// return z;
// }


//dfg


// console.log(age);
// age = parseInt(age);
// if ( age != 18 )
// {
//     console.log("True");
// }
// else
// {
//     console.log("False");
//