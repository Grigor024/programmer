// let a = 35;
// document.write(a);
// console.log(a);


// let b = prompt("Enter the key");

// if (b != 0){
//     document.write("Tumo");
// }
// else
// document.write("Poka tumo");




// let a1 = 56;
// let a2 = 100;


// if (a1 == a2){
//     document.write("Tumo");
// }
// else
// document.write("Poka tumo");



// let test1 = '3';
// let test2 = '3';

// if ( test1 === test2){
//     document.write("Tumo");
// }
// else
// document.write("Poka tumo");


// let num = prompt("Enter key");

// if (num == 0 || num < 100){
//     document.write("True");
// }
// else{
//     document.write("False");
// }

// let num = prompt("Enter the key");
		
// if (!(num >= 0 || num <= 20)) {
// 	document.write('+++');
// } else {
// 	document.write('---');
// }


let test = true;

if (!(test === true)) {
	console.log('+++');
} else {
	console.log('---');
}
