// let service = 'credit card';
// let month = 'May 30th';
// let diplayText = 'Your' + service + ' bill is due on';

// console.log(diplayText);


// let age = 50;

// console.log('Grigor is ' + age + ' years old' )


var x = 10, y = -20;
var z = Math.min(x, y);
console.log(z);