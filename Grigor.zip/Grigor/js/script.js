// let i = 60;

// for(i=0; i<=20; i++)
// {
//     document.write("<br> "+ i);
// } 



// const array = ['Yerevan', 'Moscow', 'New York', 'San Antonio'];

// let text = "";

// for (let i = 0; i < array.length; i++ )
// {
    
//     //document.write('<br>', array[i]);
// //     text += array[i] + "<br>" ;
// // }

// // document.getElementById("demo").innerHTML = text;
// //         0  1  2   3   4  ...           9
// let arr = [1, 5, 43, 6, 43, 5, 2, 5, 766, 7]




// // while(arr[count] >= 0)
// // {
// //     if(arr[count] % 2 == 0)
// //     {
// //         console.log(arr[count]);
        
// //     }

// //     count++;
// // }

// let  i = 0;
// let max = 0;



// while(i < arr.length)
// {

//     i++;
// }
// console.log(max);


// function myFunction() {
//     var x = document.createElement("BUTTON");
//     // var t = document.createText("Click me");
//     x.appendChild(t);
//     document.body.appendChild(x);
//     return ("8");
// }


//let test = prompt('enter');
//let test2 = 48

// let test1 = prompt('enter first');
// let test2 = prompt('enter second');

// //let test1 = 25;
// //let test2 = '25';

// if(test1 === test2)
// {
//     console.log('+++');
// }
// else
// {
//     console.log("---");
// }

// let num1 = prompt('enter');
// let num2 = prompt('enter');


// if (num1 <= 1 || num2 >= 3)
// {
//     document.write('verno')
// }
// else
// {
//     document.write('neverno')
// }

// let num = 3;
		
// if (!(num > 5 || num > 0 && num < 3)) {
// 	console.log('+++');
// } else {
// 	console.log('---');
// }

// let test = false;

// if (test === true)
// {
//     console.log('+++');
// }
// else
// {
//     console.log('---');
// }

// let x = 6;
// let y = 'dkhfkdjh';
// let z = true;
// let u = false;

// let r = x !== y;

// console.log(r);


// let test = true;

// if(!false)
// {
//     console.log('+++');
// }
// else
// {
//     console.log('---');
// }

// let test1 = true;
// let test2 = true;
// let test3 = true;

// if (test1 || test2 && !test3 ) { 
// 	console.log('+++');
// } else {
// 	console.log('---');
// }


// let test = 1;

// if(test == 1)
// {
//     console.log('***');
// }




// else if


// let num = prompt('enter');

// if ( num == 1 )
// {
//     console.log('+++');
// }
// else if ( num == 2 )
// {
//     console.log('---');
// }
// else if ( num == 3)
// {
//     console.log('***');
// }
// else
// {
//     console.log('Error');
// }


// let day = prompt('Enter number');

// if (day >= 1 && day < 11 )
// {
//     console.log('First decade');
// }
// else if(day >= 11 && day < 21)
// {
//     console.log('Second decade');
// }
// else if (day >= 21 && day <= 31)
// {
//     console.log('Third decade');
// }
// else
// {
//     console.log('Error');
    
// }


// let num = prompt('enter');

// if ( num >= 0)
// {
//     if ( num <= 5 )
//     {
//         console.log('menshe ili ravno');
//     }
//     else 
//     {
//         console.log('bolshe 5');
//     }

// }
// else
// {
//     console.log('menshe nulya');
// }



// let num = prompt('Enter the number');

// document.write('Entered number:  ', num, '<br>' )

// if( num < 10 || num > 99)
// {

//     alert('It`s not in 10 to 99 ');
// }
//  else
// {
// {
//     let num1 = num % 10
//     let num2 = (num - num1) / 10;
//     let num3 = num1 + num2;
    
//     document.write( 'num1: ',  num1, '<br>',
//                  'num2: ', num2,'<br>',
//                  'num3: ', num3,'<br>',);
    

// if( num3 <= 9 )
// {
//     document.write( '<br>', ' Summa ne dvuznachnaya');
// }

// else 
// {
//     document.write('<br>', ' Summa dvuznachnaya');
// }

// }
// }


// let num = prompt('mi ban','');

// switch (num) {
// 	case 1:
// 		console.log('value1');
// 	break;
// 	case 2:
// 		console.log('value2');
// 	break;
// 	case 3:
// 		console.log('value3');
// 	break;
// 	default:
// 		console.log('incorrect value');
// 	break;
// }

// let carObj = + prompt('enter');
// console.log('bar mek erku'.split(' ').length)
// switch(carObj)
// {
//     case 1:
//         document.write('Mercedes');
//         break;
//     case 2:
//         document.write('Toyota');
//         break;
//     case 3:
//         document.write('Honda');
//         break;
//         default:
//             document.write('Nothing');
// }

// sravnenie

// let a = 2 ** 4;
// let b = 4 ** 2;

// let result = a != b;

// console.log(result);


// let ok = confirm('Text answer');

// if (ok)
// {
//     document.write('verno');
// }
// else
// {
//     document.write('Neverno')
// }


// let ask = confirm ( ' Are you 18 years old ');

// if ( ask )
// {
//     alert('It`s for adult ');
// }
// else
// {
//     alert('Access is denied');
// }


// let test = false;
// let res;

// if ( test )
// {
//     res = 1;
// }
// else
// {
//     res = 2;
// }

// console.log(res);


// let age = 17;
// let adult;

// if ( age <= 18 )
// {
//     adult = true;
// }
// else
// {
//     adult = false;
// }
// console.log( adult );


// let res = 1;

// if(true)
// {
//     res = 2;
    
// }
// console.log(res);


// let age = 19;
// let res;

// if (age >= 18) {
	
	
// 	if (age <= 23) {
// 		res = 'от 18 до 23';
// 	} else {
// 		res = 'больше 23';
// 	}
// } else {
// 	res = 'меньше 18';
// }

// console.log(res);


// let min = 10;

// if ( min >= 10 && min <= 14 )
// {
//     console.log('1 chetvert');
// }
// if (min >= 15 && min <= 29)
// {
//     concole.log('2 chetvert');
// }
// if ( min >= 30 && min <= 44)
// {
//     console.log('3 chetvert');
// }
// if (min >= 45 && min <= 59)
// {
//     console.log('4 chetvert');
// }


// let max = prompt('Enter a number')

// if (max >= 1 && max <= 19)
// {
//     console.log('1/3 piece');
// }
// if (max >= 20 && max <= 39)
// {
//     console.log('2/3 piece');
// }
// if (max >= 40 && max <= 59)
// {
//     console.log('3/3 piece');
// }

// let str = '12345';

// if (str.length >= 3)
// {
//     console.log('!');
// }


// let arr = [ 5, 6 ];

// //console.log(arr[0] + arr[1] + arr[2] + arr[3] + arr[4]);

// console.log(arr.length);

// if (arr.length >= 3)
// {
//     console.log(arr[0] + arr[1] + arr[2] + arr[3] + arr[4]);
// }

// else
// {
//     console.log('v arr netu 3 elementov')
// }


// let str = '12345';
// let last = str[str.length - 1]; 

// if (last == 5);
// {
//     console.log('!');
// }

// let str = 'abskdg';

// let first = str[str.length - 6];

// console.log(first);

// if (first == 'c')
// {
//     console.log('good');
// }
// else
// {
//     console.log('mistake');
// }


// let str = 'jhyukux';

// let last = str[str.length - 1];

// console.log(last);

// if ( last = 'x')
// {
//     console.log(last + ' verno x');
// }

// let str = 'akjndib';

// let first = str[str.length - 7];

// if (first == 'a');
// {
//     console.log(first + ' Verno');
// }

// let last = str[str.length - 1];

// {
//     console.log(last + ' Verno');
// }


// let num = 12345;

// let str = String(num);

// if (str[1] == 2)
// {
//     console.log('+++');
// }
// else
// {
//     console.log('---');
// }


// let num = 12345;
// let first = String(num)[0];

// console.log(first);

// if (first == 1 || first == 2)
// {
//     console.log('+++');
// }
// else
// {
//     console.log('---');
// }



let num = 8523022;

let result = num % 2; 

if (result == 0 )
{
    console.log('verno');
}
else
{
    console.log('neverno');
}
